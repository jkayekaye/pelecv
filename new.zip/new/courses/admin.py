from django.contrib import admin
from django.http import HttpResponse

def admins (request):
    return HttpResponse ("This is the Courses")
