from django.shortcuts import render
from django.http import HttpResponse

def courses (request):
    return HttpResponse ("This is the Courses")

def bsit (request):
    return HttpResponse ("BSIT")

def bssw (request):
    return HttpResponse ("BSSW")
