from django.urls import path
from . import views

urlpatterns =[
    path('courses/', views.courses, name = "courses"),
    path('bsit/', views.bsit, name = "Bachelor of Science in Information Tech"),
    path('bssw/', views.bssw, name = "Bachelor of Science in Social Work"),
    


]