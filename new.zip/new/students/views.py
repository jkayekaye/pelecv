from django.shortcuts import render
from django.http import HttpResponse

def students (request):
    return HttpResponse ("This is the Students List")

def section_a (request):
    return HttpResponse ("This is the Students List for Section A")

def section_b (request):
    return HttpResponse ("This is the Students List for Section B")
