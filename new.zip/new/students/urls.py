from django.urls import path
from . import views

urlpatterns =[
    path('students/', views.students, name = "students"),
    path('students_a/', views.students, name = "Section A"),
    path('students_b/', views.students, name = "Section B"),
]