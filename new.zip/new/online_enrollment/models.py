from django.db import models
from django.views import View

class Student(models.Model):
    student_id = models.CharField(max_length=20)
    student_name = models.CharField(max_length=100)
    student_id = models.CharField(max_length=100)
    email = models.EmailField()
    student_password = models.CharField(max_length=100)
    student_contact = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.student_name}"

class Departments(models.Model):
    course = models.CharField(max_length=250)
    room = models.CharField(max_length=100)
    teacher_name1 = models.CharField(max_length=100)
    units = models.IntegerField(max_length=10)
    contact = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.course}"

class Subject(models.Model):
    subject = models.CharField(max_length=250)
    room = models.CharField(max_length=100)
    teacher_name = models.CharField(max_length=100)
    day = models.CharField(max_length=100)
    time = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.subject}"

class Teacher(models.Model):
    Firstname = models.CharField(max_length=100)
    Lastname = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=100)
    teacher_id = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.Firstname} {self.Lastname} "

class Requirement(models.Model):
    student_id1 = models.CharField(max_length=20)
    student_name = models.CharField(max_length=100)
    grades = models.CharField(max_length=50)
    homeroom_teach = models.CharField(max_length=100)
    student_awards = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.student_name} {self.student_awards} "
    
class Login(models.Model):
    fullname = models.CharField(max_length=100)
    lo_id = models.CharField(max_length=20)
    password = models.CharField(max_length=100)

class Register(models.Model):
    fullname = models.CharField(max_length=100)
    re_id = models.CharField(max_length=20)
    email = models.EmailField()
    password = models.CharField(max_length=100)
    confirmpassword = models.CharField(max_length=100)
