from django import forms
from .models import Login , Register ,Student, Departments


class LoginForm(forms.ModelForm):
    class Meta:
        model = Login
        fields = ['Full_name', 'Id', 'Password']
        widgets = {
            'Full_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter full name'
            }),
            'lo_id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Id'
            }),
            'password': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter password'
            }),
           
        }

    def clean_name(self):
        name = self.cleaned_data.get('Full_name')
        if len(name) < 3:
            raise forms.ValidationError("Name must be at least 3 characters long.")
        return name
    

class RegisterForm(forms.ModelForm):
    class Meta:
        model = Register
        fields = ['Full_name', 'Enter_Id', 'Email', 'Password','Confirm_password']
        widgets = {
            'Full_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter full name'
            }),
            'Enter_Id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Id'
            }),
            'Email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter valid email address'
            }),
            'Password': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter password'
            }),
            'Confirm_password': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Put password again'
            }),
            
        }

    def clean_name(self):
        name = self.cleaned_data.get('Full_name')
        if len(name) < 3:
            raise forms.ValidationError("Name must be at least 3 characters long.")
        return name





class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['Student_Name', 'Student_Id', 'Email', 'Student_Password','Student_Contact']
        widgets = {
            'Student_Name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter full name'
            }),
            'Student_Id': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Id'
            }),
            'Email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter valid email address'
            }),
            'Student_Password': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter password'
            }),
            'Student_Contact': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter valid contact number'
            }),
        }

    def clean_name(self):
        name = self.cleaned_data.get('Student_Name')
        if len(name) < 3:
            raise forms.ValidationError("Name must be at least 3 characters long.")
        return name

    def clean_course(self):
        course = self.cleaned_data.get('Course').upper()
        allowed_courses = ['BSIT', 'BSCRIM', 'BSBA']
        if course not in allowed_courses:
            raise forms.ValidationError("Course must be BSIT, BSCrim, or BSBA.")
        return course
    

class DeptForm(forms.ModelForm):
    class Meta:
        model = Departments
        fields = ['Teacher_Name', 'Room', 'Units', 'Course','Contact']
        widgets = {
            'Teacher_Name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter full name'
            }),
            'Room': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Id'
            }),
            'Units': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter valid contact number'
            }),
            'Course': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'BSIT, BSCrim, BSBA, etc.'
            }),
            'Contact': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter valid contact number'
            }),
        }

    def clean_name(self):
        name = self.cleaned_data.get('Teacher_Name')
        if len(name) < 3:
            raise forms.ValidationError("Name must be at least 3 characters long.")
        return name

    def clean_course(self):
        course = self.cleaned_data.get('Course').upper()
        allowed_courses = ['BSIT', 'BSCRIM', 'BSBA']
        if course not in allowed_courses:
            raise forms.ValidationError("Course must be BSIT, BSCrim, or BSBA.")
        return course