from django.contrib import admin
from .models import Student, Department, Subject, Teacher, Requirement

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("name", "code")
    search_fields = ("name", "code")

@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ("name", "code", "department")
    list_filter = ("department",)
    search_fields = ("name", "code")

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ("first_name", "last_name", "email", "department")
    search_fields = ("first_name", "last_name", "email")

@admin.register(Requirement)
class RequirementAdmin(admin.ModelAdmin):
    list_display = ("name",)
    search_fields = ("name",)

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ("student_id", "first_name", "last_name", "email", "department", "advisor", "created_at")
    list_filter = ("department", "advisor")
    search_fields = ("student_id", "first_name", "last_name", "email")
    filter_horizontal = ("subjects", "requirements")