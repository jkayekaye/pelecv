from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import LoginForm, RegisterForm, StudentForm
from .models import Student

def loginform(request):
    if request.user.is_authenticated:
        return redirect('online_enrollment:dashboard')

    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, "Login successful.")
            return redirect('online_enrollment:dashboard')
        else:
            messages.error(request, "Invalid credentials.")
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})


def registerform(request):
    if request.user.is_authenticated:
        return redirect('online_enrollment:dashboard')

    if request.method == 'POST':
        reg_form = RegisterForm(request.POST)
        if reg_form.is_valid():
            reg_form.save()
            messages.success(request, "Account created. Please log in.")
            return redirect('online_enrollment:loginform')
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        reg_form = RegisterForm()
    return render(request, 'register.html', {'reg_form': reg_form})


@login_required(login_url='online_enrollment:loginform')
def dashboard(request):
    # Show student's summary/profile; if no Student record exists, prompt to add details
    student = None
    try:
        student = Student.objects.filter(user=request.user).first()
    except Exception:
        student = None

    return render(request, 'dashboard.html', {'student': student})


@login_required(login_url='online_enrollment:loginform')
def profile_edit(request):
    # create or edit Student linked to current user
    student, created = Student.objects.get_or_create(user=request.user, defaults={
        'student_id': f"SID-{request.user.id}",
        'first_name': request.user.first_name or '',
        'last_name': request.user.last_name or '',
        'email': request.user.email or ''
    })
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.instance.user = request.user
            form.save()
            messages.success(request, "Profile saved.")
            return redirect('online_enrollment:dashboard')
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = StudentForm(instance=student)

    return render(request, 'profile_edit.html', {'form': form, 'student': student})


def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('online_enrollment:loginform')