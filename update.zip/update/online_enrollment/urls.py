from django.urls import path
from . import views

app_name = 'online_enrollment'

urlpatterns = [
    path('login/', views.loginform, name='loginform'),
    path('register/', views.registerform, name='registerform'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
    path('logout/', views.logout_view, name='logout'),
]