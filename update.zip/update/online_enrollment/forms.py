from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Student, Department, Subject, Teacher, Requirement

User = get_user_model()

class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data.get('email')
        if commit:
            user.save()
        return user

class LoginForm(AuthenticationForm):
    # uses Django's authentication; template will render username/password
    pass

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = [
            'student_id', 'first_name', 'last_name', 'email', 'contact',
            'department', 'subjects', 'advisor', 'requirements'
        ]
        widgets = {
            'student_id': forms.TextInput(attrs={'placeholder': 'Student ID'}),
            'first_name': forms.TextInput(attrs={'placeholder': 'First name'}),
            'last_name': forms.TextInput(attrs={'placeholder': 'Last name'}),
            'email': forms.EmailInput(attrs={'placeholder': 'Email'}),
            'contact': forms.TextInput(attrs={'placeholder': 'Contact number'}),
            'department': forms.Select(),
            'subjects': forms.SelectMultiple(attrs={'size': 6}),
            'advisor': forms.Select(),
            'requirements': forms.SelectMultiple(attrs={'size': 6}),
        }