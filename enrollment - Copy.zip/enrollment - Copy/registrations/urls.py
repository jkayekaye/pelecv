from django.urls import path
from . import views

urlpatterns =[
    path('registrations/', views.registrations, name = "registrations"),
    path('contacts/', views.contacts, name = "contacts details"),
    path('payments/', views.payments, name = "payments here"),
]