from django.shortcuts import render
from django.http import HttpResponse

def registrations (request):
    return HttpResponse ("This is the Registrations List")

def contacts (request):
    return HttpResponse ("contacts")

def payments (request):
    return HttpResponse ("payments")
