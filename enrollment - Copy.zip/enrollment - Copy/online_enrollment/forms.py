from django import forms
from .models import Login , Register


class LoginForm(forms.ModelForm):
    class Meta:
        model = Login
        fields = ['fullname', 'lo_id', 'password']
        widgets = {
            'fullname': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter full name'
            }),
            'lo_id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Id'
            }),
            'password': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter password'
            }),
           
        }

    def clean_name(self):
        name = self.cleaned_data.get('fullname')
        if len(name) < 3:
            raise forms.ValidationError("Name must be at least 3 characters long.")
        return name
    

class RegisterForm(forms.ModelForm):
    class Meta:
        model = Register
        fields = ['fullname', 're_id', 'email', 'password','confipassword']
        widgets = {
            'fullname': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter full name'
            }),
            're_id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter Id'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter valid email address'
            }),
            'password': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter password'
            }),
            'confipassword': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'BSIT, BSCrim, BSBA, etc.'
            }),
            
        }

    def clean_name(self):
        name = self.cleaned_data.get('fullname')
        if len(name) < 3:
            raise forms.ValidationError("Name must be at least 3 characters long.")
        return name





# class StudentForm(forms.ModelForm):
#     class Meta:
#         model = Student
#         fields = ['student_id', 'student_name', 'email', 'student_password','student_contact']
#         widgets = {
#             'student_name': forms.TextInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'Enter full name'
#             }),
#             'student_name': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'Enter Id'
#             }),
#             'email': forms.EmailInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'Enter valid email address'
#             }),
#             'course': forms.TextInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'BSIT, BSCrim, BSBA, etc.'
#             }),
#             'student_contact': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'Enter valid contact number'
#             }),
#         }

#     def clean_name(self):
#         name = self.cleaned_data.get('student_name')
#         if len(name) < 3:
#             raise forms.ValidationError("Name must be at least 3 characters long.")
#         return name

#     def clean_course(self):
#         course = self.cleaned_data.get('course').upper()
#         allowed_courses = ['BSIT', 'BSCRIM', 'BSBA']
#         if course not in allowed_courses:
#             raise forms.ValidationError("Course must be BSIT, BSCrim, or BSBA.")
#         return course
    

# class DeptForm(forms.ModelForm):
#     class Meta:
#         model = Departments
#         fields = ['teacher_name1', 'room', 'units', 'course','contact']
#         widgets = {
#             'teacher_name1': forms.TextInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'Enter full name'
#             }),
#             'room': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'Enter Id'
#             }),
#             'units': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'Enter valid contact number'
#             }),
#             'course': forms.TextInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'BSIT, BSCrim, BSBA, etc.'
#             }),
#             'contact': forms.NumberInput(attrs={
#                 'class': 'form-control',
#                 'placeholder': 'Enter valid contact number'
#             }),
#         }

#     def clean_name(self):
#         name = self.cleaned_data.get('student_name')
#         if len(name) < 3:
#             raise forms.ValidationError("Name must be at least 3 characters long.")
#         return name

#     def clean_course(self):
#         course = self.cleaned_data.get('course').upper()
#         allowed_courses = ['BSIT', 'BSCRIM', 'BSBA']
#         if course not in allowed_courses:
#             raise forms.ValidationError("Course must be BSIT, BSCrim, or BSBA.")
#         return course