from django.urls import path
from . import views

urlpatterns = [
    # path('student_profile/', views.student_profile, name="Student Profile"),
    path('register/', views.register_form, name="register form"),
    path('login/', views.login_form, name='login form'),
    # path('department_list/', views.department_list, name="Department List"),
    # path('subjects_list/', views.subjects_list, name="Subjects List"),
    # path('teacher_list/', views.teacher_list, name="Teachers List"),
    # path('requirement_list/', views.requirement_list, name="Requirememts List"),
    # path('fbv/', views.hello_world, name="Function Based"),
    # path('cbv/', views.HelloWorldView.as_view(), name="Class Based"),
    


]