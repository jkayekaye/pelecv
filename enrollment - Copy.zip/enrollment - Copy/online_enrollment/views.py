from django.shortcuts import render , redirect
from django.http import HttpResponse
from django.views import View
from .forms import LoginForm , RegisterForm
from django.contrib import messages


def login_form(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Login successfully!")
            return redirect('register_form')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})


def register_form(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Login successfully!")
            return redirect('login_form')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})





# def enroll_student(request):
#     if request.method == 'POST':
#         form = StudentForm(request.POST)
#         if form.is_valid():
#             form.save()
#             messages.success(request, "Student enrolled successfully!")
#             return redirect('enroll_success')
#         else:
#             messages.error(request, "Please correct the errors below.")
#     else:
#         form = StudentForm()
#     return render(request, 'enroll.html', {'form': form})

# def enroll_success(request):
#     return render(request, 'success.html')


# def student_list(request):
#     students = [
#         {"name":Student},
       
      
#         # {"name":"Juan Cruz","age":21}
#     ]
#     return render(request,'student_list.html',{"students":students})

# def student_list(request):
#     students = Student.objects.all()  # Fetch all members
#     return render(request, 'student_list.html', {'students': students})

# def department_list(request):
#     departments = Departments.objects.all()  # Fetch all members
#     return render(request, 'department_list.html', {'departments': departments})

# def subjects_list(request):
#     subjects = Subject.objects.all()  # Fetch all members
#     return render(request, 'subjects_list.html', {'subjects': subjects})

# def teacher_list(request):
#     teacher = Teacher.objects.all()  # Fetch all members
#     return render(request, 'teacher_list.html', {'teacher': teacher})

# def requirement_list(request):
#     requirement = Requirement.objects.all()  # Fetch all members
#     return render(request, 'requirement_list.html', {'requirement': requirement})